package universite_paris8.iut.lefarwestenperil.sae2_04.Modele.Entites;

public interface Action {
    void agit();
}
