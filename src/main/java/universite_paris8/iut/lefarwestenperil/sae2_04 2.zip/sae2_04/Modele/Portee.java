package universite_paris8.iut.lefarwestenperil.sae2_04.Modele;

public class Portee {

    /**
     * Classe Portee:
     * <p>
     *     Cette classe s'occupe des constantes de portée
     * </p>
     */
    public static int PORTEEFLECHE = 10;
    public static int PORTEEBOMBE = 64;
}
