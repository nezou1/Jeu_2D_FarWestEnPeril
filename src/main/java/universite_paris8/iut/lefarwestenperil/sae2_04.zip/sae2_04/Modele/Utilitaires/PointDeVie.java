package universite_paris8.iut.lefarwestenperil.sae2_04.Modele.Utilitaires;

public class PointDeVie {

    public static int PVLINK = 16;
}
